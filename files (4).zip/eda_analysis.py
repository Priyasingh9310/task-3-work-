import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from scipy import stats
sns.set_theme(style="whitegrid")
df = pd.read_csv("titanic.csv")
print(df.shape); print(df.isna().sum()[lambda s:s>0])
print(df.describe().round(2))
# cleaning
df['age']=df['age'].fillna(df.groupby(['sex','pclass'])['age'].transform('median'))
df['embarked']=df['embarked'].fillna(df['embarked'].mode()[0])
df['embark_town']=df['embark_town'].fillna('Southampton')
df['family']=df.sibsp+df.parch+1
df['ageband']=pd.cut(df.age,[0,12,18,35,60,100],labels=['Child','Teen','Young adult','Adult','Senior'])
print(df.groupby('sex').survived.mean().round(3))
print(df.groupby('pclass').survived.mean().round(3))
print(df.groupby('ageband',observed=True).survived.mean().round(3))
print(df.groupby('family').survived.agg(['mean','count']).round(3))
print(df.groupby('embark_town').survived.mean().round(3))
num=df[['survived','pclass','age','sibsp','parch','fare','family']]
print(num.corr().round(3)['survived'])
# chi-square
for c in ['sex','pclass','embark_town']:
    ct=pd.crosstab(df[c],df.survived); print(c, stats.chi2_contingency(ct)[1])
print(stats.ttest_ind(df[df.survived==1].fare,df[df.survived==0].fare,equal_var=False))
print(df.groupby(['sex','pclass']).survived.mean().round(3))
# plots
f,ax=plt.subplots(1,2,figsize=(10,4))
sns.countplot(x='survived',data=df,ax=ax[0],palette=['#d9534f','#5cb85c']);ax[0].set_xticklabels(['Died','Survived']);ax[0].set_title('Survival count')
sns.histplot(df.age,bins=30,kde=True,ax=ax[1],color='#337ab7');ax[1].set_title('Age distribution')
plt.tight_layout();plt.savefig('out/1_overview.png',dpi=130);plt.close()
f,ax=plt.subplots(1,3,figsize=(14,4))
sns.barplot(x='sex',y='survived',data=df,ax=ax[0],errorbar=None,palette='Set2');ax[0].set_title('Survival rate by sex')
sns.barplot(x='pclass',y='survived',data=df,ax=ax[1],errorbar=None,palette='Set2');ax[1].set_title('Survival rate by class')
sns.barplot(x='ageband',y='survived',data=df,ax=ax[2],errorbar=None,palette='Set2');ax[2].set_title('Survival rate by age band');ax[2].tick_params(axis='x',rotation=20)
plt.tight_layout();plt.savefig('out/2_survival_rates.png',dpi=130);plt.close()
plt.figure(figsize=(7,4));sns.barplot(x='pclass',y='survived',hue='sex',data=df,errorbar=None,palette='Set1');plt.title('Survival rate by class and sex');plt.tight_layout();plt.savefig('out/3_class_sex.png',dpi=130);plt.close()
f,ax=plt.subplots(1,2,figsize=(11,4))
sns.boxplot(x='survived',y='fare',data=df,ax=ax[0]);ax[0].set_yscale('log');ax[0].set_title('Fare vs survival (log scale)')
sns.kdeplot(data=df,x='age',hue='survived',fill=True,ax=ax[1],common_norm=False);ax[1].set_title('Age density by survival')
plt.tight_layout();plt.savefig('out/4_fare_age.png',dpi=130);plt.close()
plt.figure(figsize=(6.5,5));sns.heatmap(num.corr(),annot=True,fmt='.2f',cmap='coolwarm',center=0);plt.title('Correlation heatmap');plt.tight_layout();plt.savefig('out/5_corr.png',dpi=130);plt.close()
